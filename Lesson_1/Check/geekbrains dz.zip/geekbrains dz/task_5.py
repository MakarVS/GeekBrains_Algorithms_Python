alphabet = 'abcdefghijklmnopqrstuvwxyz'
n = int(input('введите номер буквы '))
print(f'буква {alphabet[n-1]}')
